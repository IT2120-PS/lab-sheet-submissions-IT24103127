setwd("C:\\Users\\Heshani\\Documents\\IT24103127")

data <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
colnames(data) <- c("Weight")

weights <- as.numeric(data$Weight)

#Population Mean and Standard Deviation
pop_mean <- mean(weights)
pop_sd <- sd(weights)

#sample mean and sample standard deviation
samples <- c()
n <- c()
for(i in 1:25) {
  s <- sample(weights, 6, replace=TRUE)
  samples <- cbind(samples, s)
  n <- c(n, paste("s", i))
}
colnames(samples) <- n
s_means <- apply(samples, 2, mean)
s_sds <- apply(samples, 2, sd)

#Q3
mean_of_sample_means <- mean(s_means)
sd_of_sample_means <- sd(s_means)

